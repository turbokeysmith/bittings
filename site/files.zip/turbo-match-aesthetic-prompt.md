# Turbo Keysmith — Make Every Page Match the Premium Design (paste into Claude Code)

**Attach these in Claude Code before running:**
- `turbo-premium.html` — the approved look. **This is the single source of visual truth.** Every page must end up matching its aesthetic exactly.
- My website repo (`_live-clone`). The public site lives in the `site/` folder.

Your job: restyle and lightly **restructure** all ~220 pages so they look like `turbo-premium.html` — blackout-premium, automotive, chrome + red on true black. Keep every page's words, links, and SEO. This is a look-and-feel overhaul, not a content rewrite.

---

## What I already know about my repo (don't re-discover, just verify)
- `site/` = the public website. Plain static HTML, **no build step, no includes** — the header and footer are copy-pasted into each page.
- **One shared stylesheet:** `site/assets/styles.css`, already linked by every page. This is the main lever.
- Shared class names exist on every page: `header.site`, `.brandbar`, `.bar`, `nav.main`, `nav.mobile`, `.navtoggle`, `.subbar`, `.wrap`, `.btn`/`.btn-call`/`.btn-red`/`.btn-ghost`, `.hero`, `.trust`, `.cards`/`.scard`, `.sec-head`, `section`/`.surface`, `.steps`/`.step`, `.info-grid`, `.faq-item`, `.mapbox`, `.award-badge`, `.social-icons`, `footer.site`, `.mobilebar`, `.prose`.
- Logo file: `site/assets/logo.png`, referenced with `../` prefixes depending on folder depth.
- Spanish mirror under `site/es/` (full Spanish pages). Translatable elements use `data-i18n` / `data-i18n-html` attributes read by `site/assets/i18n.js`.
- Reviews are a live widget (localmarketingmanager iframe + inline script). Keep it.
- Page types: homepage; city landing pages (e.g. `oklahoma-city/`); city service pages (`oklahoma-city/automotive|residential|commercial/`); content pages (`financing/`, `warranty/`, `faq/`, `certifications/`, `blog/`, `emergency/`, `contact/`, `pay-now/`, `service-areas/`, `terms/`, plus `nastf/`, `omla/`, `okbfaa/`, `oklahoma-license/`, `keyless2go/`); and the `es/` mirror of all of it.

## Hard rules — never break these (rankings depend on it)
- Do **not** change on any page: URL/slug/filename, `<title>`, meta description, canonical, `hreflang` links, JSON-LD/LocalBusiness schema, `sitemap.xml`, `robots.txt`, image `alt` text, or any `data-i18n`/`data-i18n-html` attribute and its value.
- Keep name/address/phone byte-for-byte: `Turbo Keysmith LLC · 4201 N MacArthur Blvd, Warr Acres, OK 73122 · (405) 870-5397`.
- `site/es/` pages stay `noindex`, keep their `hreflang`, get the same look — do not publish/index them.
- Work on the **staging / `pages.dev`** build only. Don't push live or touch DNS.
- Free assets only (Google Fonts OK). Nothing that costs money without asking.
- Don't stall on me: if you need a decision, make the safe choice, leave a `TODO(turbo):` comment, keep going, and list them all at the end.

## Match the reference exactly — design system
Pull these from `turbo-premium.html` and reproduce them in a rebuilt `site/assets/styles.css` so the whole site inherits them:

**Tokens**
```
--bg:#000000  --bg2:#08090B  --panel:#101216  --line:#22262E  --line2:#2E333C
--ink:#F4F5F6  --mut:#9AA0A8
--red:#D62A3D  --red-hi:#EC4A58  --red-lo:#9E1521
--chrome:#C2C6CA  --chrome-hi:#EDEFF1  --chrome-lo:#878D94
chrome gradient: linear-gradient(180deg,#F2F3F4,#C9CDD1 45%,#878D94 55%,#E4E6E8)
red gradient:    linear-gradient(135deg,#EC4A58,#D62A3D 48%,#9E1521)
```
**Fonts:** Saira (headings/labels, 600–800) + Inter (body), Google Fonts.

**Components to reproduce 1:1 from the reference:** sticky black header, premium hero (red glow + chrome hairline), stat/trust strip, service cards (chrome top-border that turns red on hover, **SVG line icons — no emoji anywhere**), the "Why Turbo" credibility band, numbered how-it-works steps, review cards/strip, the big red CTA band, and the dark footer. Buttons: primary = red gradient with glow; secondary = ghost with chrome border.

## Logo rules — IMPORTANT (this is what looked off before)
The full logo already contains the words "TURBO KEYSMITH," so never place the full lockup right next to a text headline — it reads as a duplicate and feels cluttered.
- **Header (all pages):** the **emblem only** (the turbo + wing + gear icon, *no wordmark text*) at ~40px, followed by the wordmark as HTML text — "TURBO" in silver/chrome, "KEYSMITH" in red, in Saira. This matches the reference header.
- **Hero art:** use the **emblem only** (icon, no text) as the graphic opposite the headline — so it doesn't repeat the words already in the header and the H1.
- Create an emblem-only asset: crop the wordmark off the existing logo, or export from the transparent vector (`print_transparent.svg`). Save as `site/assets/logo-mark.svg` (preferred, scales crisp) or `.png`. Place raster logos only on pure-black areas, or use the transparent SVG anywhere.

## Per-page-type structure (map existing content into the premium components)
Keep each page's real text; just rehouse it in the reference's components.
- **Homepage:** premium hero (emblem + existing H1/lead/CTAs, i18n intact) → trust strip → 4 service cards (SVG icons) → Why-Turbo band → financing/warranty cards → how-it-works → reviews widget → map → contact → CTA band → footer.
- **City landing pages:** premium hero with the city's existing headline → trust strip → the 3 service cards → Why-Turbo band → the page's existing local prose → map → CTA band → footer.
- **City service pages (automotive/residential/commercial):** premium hero → existing content in premium `.prose` → CTA band → footer.
- **Content pages (financing, warranty, faq, certifications, blog, emergency, contact, terms, pay-now, service-areas, nastf, etc.):** premium header/footer + existing content in premium `.prose` / `.faq-item` / `.info-grid` + CTA band.
- **`es/` mirror:** identical components, Spanish content, stays `noindex`.

## Process
1. **Recon:** confirm the structure above, report how header/footer are duplicated across files, then continue.
2. **Build the design system once** in `site/assets/styles.css` to match the reference. Every page already links it.
3. **Update the shared header + footer markup** to the premium structure across all pages (since there are no includes, apply the same change consistently to every file; keep all existing nav links, `data-i18n` attributes, social icons, the reviews widget, and the mobile call bar).
4. **Pilot:** do the homepage + one city landing + one city service page + one content page + one `es/` page. **Stop and let me compare them side-by-side against `turbo-premium.html`.**
5. After I approve, roll the same patterns across every remaining page.

## Acceptance check (before you call it done)
- Open each page **type** next to `turbo-premium.html` — same black background, same chrome/red accents, same Saira headings + Inter body, same card/button/header/footer treatment. They should look like one family.
- No emoji icons left anywhere (all replaced with SVG).
- No headline sitting beside a full wordmark logo (emblem-only per Logo rules).
- Zero changes to titles, meta, schema, hreflang, i18n values, or NAP. Reviews widget and language toggle still work.
- Summarize changes, list all `TODO(turbo):` notes, and tell me how to preview the staging build. **Stop at staging — don't go live.**

## Two things I'll owe you — just leave TODO notes and keep moving
- Confirm my real business hours (current pages show "24 Hours, Mon–Sat / Sunday until 5am").
- Reviews come from the live Google widget, so leave that as-is.
